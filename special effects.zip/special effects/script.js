$(document).ready(function() {
    $("#menu").accordion({collapsible: true, active: false});
});