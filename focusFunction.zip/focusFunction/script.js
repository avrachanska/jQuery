$(document).ready(function() {
    $('input').focus(function() {
        $(this).css('outline-color', '#FF0000');
    });
});