$(document).ready(function() {
    $('#car').draggable();
});