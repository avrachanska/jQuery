$(document).ready(function() {
    $('div').fadeOut('fast');
});