$(document).ready(function() {
    $('div').click(function() {
        $(this).fadeOut('fast');
    });
});